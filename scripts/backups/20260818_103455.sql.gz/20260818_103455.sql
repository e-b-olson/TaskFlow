--
-- PostgreSQL database dump
--

\restrict 3KGIW23vcDeaa29hw24orcaYoZa50rlgsCPrDG4nXQJwBtbXcGx8cwoiTh7DkD2

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_streaks; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.daily_streaks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    last_completed_date date,
    completed_task_id integer
);


ALTER TABLE public.daily_streaks OWNER TO todo_user;

--
-- Name: daily_streaks_id_seq; Type: SEQUENCE; Schema: public; Owner: todo_user
--

CREATE SEQUENCE public.daily_streaks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_streaks_id_seq OWNER TO todo_user;

--
-- Name: daily_streaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: todo_user
--

ALTER SEQUENCE public.daily_streaks_id_seq OWNED BY public.daily_streaks.id;


--
-- Name: task_list_items; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.task_list_items (
    id integer NOT NULL,
    task_list_id integer NOT NULL,
    task_id integer NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_list_items OWNER TO todo_user;

--
-- Name: task_list_items_id_seq; Type: SEQUENCE; Schema: public; Owner: todo_user
--

CREATE SEQUENCE public.task_list_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_list_items_id_seq OWNER TO todo_user;

--
-- Name: task_list_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: todo_user
--

ALTER SEQUENCE public.task_list_items_id_seq OWNED BY public.task_list_items.id;


--
-- Name: task_lists; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.task_lists (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_lists OWNER TO todo_user;

--
-- Name: task_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: todo_user
--

CREATE SEQUENCE public.task_lists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_lists_id_seq OWNER TO todo_user;

--
-- Name: task_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: todo_user
--

ALTER SEQUENCE public.task_lists_id_seq OWNED BY public.task_lists.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    deadline timestamp with time zone,
    time_estimate_minutes integer,
    effort text DEFAULT 'MEDIUM'::text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    cost real,
    materials text,
    CONSTRAINT tasks_effort_check CHECK ((effort = ANY (ARRAY['HIGH'::text, 'MEDIUM'::text, 'LOW'::text]))),
    CONSTRAINT tasks_priority_check CHECK ((priority = ANY (ARRAY['HIGH'::text, 'MEDIUM'::text, 'LOW'::text]))),
    CONSTRAINT tasks_status_check CHECK ((status = ANY (ARRAY['PENDING'::text, 'IN_PROGRESS'::text, 'COMPLETE'::text])))
);


ALTER TABLE public.tasks OWNER TO todo_user;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: todo_user
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO todo_user;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: todo_user
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO todo_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: todo_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO todo_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: todo_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: daily_streaks id; Type: DEFAULT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.daily_streaks ALTER COLUMN id SET DEFAULT nextval('public.daily_streaks_id_seq'::regclass);


--
-- Name: task_list_items id; Type: DEFAULT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_list_items ALTER COLUMN id SET DEFAULT nextval('public.task_list_items_id_seq'::regclass);


--
-- Name: task_lists id; Type: DEFAULT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_lists ALTER COLUMN id SET DEFAULT nextval('public.task_lists_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: daily_streaks; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.daily_streaks (id, user_id, current_streak, last_completed_date, completed_task_id) FROM stdin;
\.


--
-- Data for Name: task_list_items; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.task_list_items (id, task_list_id, task_id, "position", added_at) FROM stdin;
1	2	6	0	2026-07-23 19:20:47+00
6	3	9	0	2026-07-23 21:11:43+00
17	6	6	0	2026-07-30 16:55:08.462159+00
16	6	7	1	2026-07-30 16:55:08.456395+00
14	4	20	0	2026-07-30 16:52:38.17386+00
15	4	11	1	2026-07-30 16:53:17.031214+00
12	4	18	2	2026-07-30 16:52:38.155039+00
13	4	19	3	2026-07-30 16:52:38.168284+00
5	1	8	0	2026-07-23 19:42:45+00
4	1	5	1	2026-07-23 19:25:40+00
2	1	4	2	2026-07-23 19:25:40+00
3	1	3	3	2026-07-23 19:25:40+00
\.


--
-- Data for Name: task_lists; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.task_lists (id, user_id, name, description, created_at) FROM stdin;
1	1	Everyday ToDo List	\N	2026-07-23 19:19:50+00
2	1	My Afternoon Tasks	Auto-generated list for 60 minutes	2026-07-23 19:20:47+00
3	1	House Tasks	\N	2026-07-23 21:11:43+00
4	1	Task Flow	This list is for features in Task Flow	2026-07-25 07:11:15+00
6	1	Car	\N	2026-07-30 16:55:08.447742+00
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.tasks (id, user_id, title, description, status, created_at, started_at, completed_at, deadline, time_estimate_minutes, effort, priority, cost, materials) FROM stdin;
1	1	Setup Autopay for Health Insurance	\N	PENDING	2026-07-23 19:14:37+00	\N	\N	\N	60	MEDIUM	MEDIUM	\N	\N
2	1	Deposit Checks	\N	PENDING	2026-07-23 19:15:08+00	\N	\N	\N	45	MEDIUM	MEDIUM	\N	\N
3	1	Clean Kitchen	\N	PENDING	2026-07-23 19:16:11+00	\N	\N	\N	60	HIGH	MEDIUM	\N	\N
4	1	Clean Bathroom	\N	PENDING	2026-07-23 19:16:37+00	\N	\N	\N	120	HIGH	MEDIUM	\N	\N
5	1	Wash Bedding	\N	PENDING	2026-07-23 19:16:59+00	\N	\N	\N	120	MEDIUM	MEDIUM	\N	\N
8	1	Process Mail	\N	PENDING	2026-07-23 19:42:35+00	\N	\N	\N	60	MEDIUM	MEDIUM	\N	\N
9	1	Fix Front Door	\N	PENDING	2026-07-23 21:11:35+00	\N	\N	\N	120	HIGH	MEDIUM	\N	\N
10	1	Buy Gift for Josh	\N	PENDING	2026-07-23 23:30:02+00	\N	\N	2026-09-15 16:29:00+00	500	MEDIUM	MEDIUM	\N	\N
12	1	Migrate To PostgreSQL Database	\N	COMPLETE	2026-07-27 17:16:12.441096+00	2026-07-27 17:16:19.85+00	2026-07-27 17:16:22.213+00	\N	60	MEDIUM	MEDIUM	\N	\N
13	1	Create Flask API Server	\N	COMPLETE	2026-07-27 17:52:51.878897+00	2026-07-27 17:52:56.965+00	2026-07-27 17:52:57.979+00	\N	30	MEDIUM	MEDIUM	\N	\N
14	1	Upgrade Linux Server	Need to upgrade from Debian 10 to Debian 11 (buster to bullseye).	PENDING	2026-07-28 16:45:02.27243+00	\N	\N	\N	120	MEDIUM	MEDIUM	\N	\N
16	1	Upgrade Linux Server (Buster --> Bullseye)	Need to upgrade from Debian 10 to Debian 11 (buster to bullseye).	PENDING	2026-07-29 16:17:55.497972+00	\N	\N	\N	120	MEDIUM	MEDIUM	\N	\N
18	1	Create Quick Task Creation	I want a faster way to just make a placeholder task - title and priority only.	COMPLETE	2026-07-30 15:56:39.270856+00	2026-07-30 16:53:23.712192+00	2026-07-30 16:53:25.278068+00	\N	\N	MEDIUM	MEDIUM	\N	\N
19	1	Create Simple Task View	I want a way to just see a list of tasks (not a grid) with simplified information (Title, Status, Priority, Time Estimate).	COMPLETE	2026-07-30 15:58:09.230006+00	2026-07-30 16:53:29.263047+00	2026-07-30 16:53:29.917664+00	\N	\N	MEDIUM	MEDIUM	\N	\N
7	1	Fix Tailgate	\N	COMPLETE	2026-07-23 19:18:55+00	2026-07-30 16:55:13.361004+00	2026-07-30 16:55:15.052118+00	\N	60	HIGH	MEDIUM	\N	Glue or Epoxy\nClip removal tool\nScrewdriver
11	1	Add Agent Generated Product Suggestions	\N	PENDING	2026-07-25 07:11:13+00	\N	\N	\N	60	MEDIUM	MEDIUM	\N	\N
20	1	TaskFlow - Add key bindings for desktop users	\N	PENDING	2026-07-30 16:50:07.37488+00	\N	\N	\N	\N	MEDIUM	LOW	\N	\N
6	1	Schedule Car Service	\N	COMPLETE	2026-07-23 19:17:42+00	2026-08-03 22:26:45.536709+00	2026-08-04 05:27:40.558297+00	\N	30	MEDIUM	HIGH	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.users (id, username, email, password_hash, created_at) FROM stdin;
1	erik	e.b.olson.mobile@gmail.com	$2a$10$fVkRnhjiZI02tnbXA6MxZOcoj/3C96Sdjo4g1PENpEa3F.YT8eVFa	2026-07-23 19:13:06+00
\.


--
-- Name: daily_streaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: todo_user
--

SELECT pg_catalog.setval('public.daily_streaks_id_seq', 1, false);


--
-- Name: task_list_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: todo_user
--

SELECT pg_catalog.setval('public.task_list_items_id_seq', 17, true);


--
-- Name: task_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: todo_user
--

SELECT pg_catalog.setval('public.task_lists_id_seq', 6, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: todo_user
--

SELECT pg_catalog.setval('public.tasks_id_seq', 20, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: todo_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: daily_streaks daily_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.daily_streaks
    ADD CONSTRAINT daily_streaks_pkey PRIMARY KEY (id);


--
-- Name: daily_streaks daily_streaks_user_id_key; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.daily_streaks
    ADD CONSTRAINT daily_streaks_user_id_key UNIQUE (user_id);


--
-- Name: task_list_items task_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_list_items
    ADD CONSTRAINT task_list_items_pkey PRIMARY KEY (id);


--
-- Name: task_list_items task_list_items_task_list_id_task_id_key; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_list_items
    ADD CONSTRAINT task_list_items_task_list_id_task_id_key UNIQUE (task_list_id, task_id);


--
-- Name: task_lists task_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_lists
    ADD CONSTRAINT task_lists_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_daily_streaks_user_id; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_daily_streaks_user_id ON public.daily_streaks USING btree (user_id);


--
-- Name: idx_task_list_items_list; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_task_list_items_list ON public.task_list_items USING btree (task_list_id);


--
-- Name: idx_task_list_items_task; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_task_list_items_task ON public.task_list_items USING btree (task_id);


--
-- Name: idx_task_lists_user_id; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_task_lists_user_id ON public.task_lists USING btree (user_id);


--
-- Name: idx_tasks_deadline; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_tasks_deadline ON public.tasks USING btree (deadline);


--
-- Name: idx_tasks_priority; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_tasks_priority ON public.tasks USING btree (priority);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: daily_streaks daily_streaks_completed_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.daily_streaks
    ADD CONSTRAINT daily_streaks_completed_task_id_fkey FOREIGN KEY (completed_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: daily_streaks daily_streaks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.daily_streaks
    ADD CONSTRAINT daily_streaks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_list_items task_list_items_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_list_items
    ADD CONSTRAINT task_list_items_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_list_items task_list_items_task_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_list_items
    ADD CONSTRAINT task_list_items_task_list_id_fkey FOREIGN KEY (task_list_id) REFERENCES public.task_lists(id) ON DELETE CASCADE;


--
-- Name: task_lists task_lists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.task_lists
    ADD CONSTRAINT task_lists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 3KGIW23vcDeaa29hw24orcaYoZa50rlgsCPrDG4nXQJwBtbXcGx8cwoiTh7DkD2

